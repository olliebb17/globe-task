//Page 391 in the JavaFX Textbook
package spherejavafx;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.*;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.Scanner;


public class SphereJavaFX extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Scanner input = new Scanner(System.in);
       
        StackPane root = new StackPane();
        
        //root.getChildren().add(btn);
        Scene scene = new Scene(root, 300, 300);
        PerspectiveCamera camera = new PerspectiveCamera(true);
        
        //Backs the camera away from the scene by 1000 units
        camera.setTranslateZ(-1000);
        
        //This is the range of which the camera will render objects
        System.out.println("would you like to increase the range of which the camera on nearobject, Yes or No");
        String q1yn = input.next();
        if (q1yn.equals("Yes")){
            System.out.println("what would you like to change it to? number");
            long nearclip = input.nextLong();
            camera.setNearClip(nearclip);
        }
        else{
            camera.setNearClip(0.1);
        }
        
        System.out.println("would you like to increase the setfar render distance please Yes or No");
        String q3yn = input.next();
        if (q3yn.equals("Yes")){
            System.out.println("how far would you like to change it to?, normally on 2000.0");
            long q4radius = input.nextLong();
            camera.setFarClip(q4radius);
        }
        else{
            camera.setFarClip(2000.0);
        }
        
        
        //The default field of view for the scene is 30 but change to suit
        camera.setFieldOfView(30);
        scene.setCamera(camera);
        
        //This sets up my sphere
        Sphere mysphere = new Sphere(200);
        mysphere.setTranslateX(-180);
        mysphere.setTranslateY(-100);
        mysphere.setTranslateZ(100);
        root.getChildren().add(mysphere);
        
        //This sets up the image of the earth to wrap around my sphere
        Image earthImage = new Image("file:earth.jpg");
        PhongMaterial earthPhong = new PhongMaterial();
        earthPhong.setDiffuseMap(earthImage);
        mysphere.setMaterial(earthPhong);
        
        //This rotates my sphere
        RotateTransition rotate = new RotateTransition();
        rotate.setNode(mysphere);
        System.out.println("Would you like to increase the rate of which the globe spins?");
        String q6yn = input.next();
        if (q6yn.equals("Yes")){
            System.out.println("what would you like to change the number to? normally 5000, the bigger the number the slower it is");
            long q7 = input.nextLong();
            rotate.setDuration(Duration.millis(q7));
        }
        else{
            rotate.setDuration(Duration.millis(5000));
        }
        rotate.setAxis(Rotate.Y_AXIS);
        rotate.setByAngle(-360);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.play();
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
        
    }
    
}
